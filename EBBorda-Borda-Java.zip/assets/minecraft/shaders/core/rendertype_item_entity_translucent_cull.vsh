#version 330

#moj_import <minecraft:light.glsl>
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

// Igual ao vanilla, exceto pelo quadrado marcador do EBBorda (textura ebborda:item/borda, cor
// #EB0BDA; ebborda:item/borda_verde, #0BEBDA, quando a borda está abrindo). O plugin põe o quadrado
// com centro no centro da borda e lado = diâmetro; aqui ele vira um quadro na tela inteira e o .fsh
// desenha a parede redonda por cima.

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in vec2 UV1;
in ivec2 UV2;
in vec3 Normal;

uniform sampler2D Sampler0;
uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;
out vec2 texCoord1;
out vec2 texCoord2;

flat out int ebBorda;
flat out float ebAlfa;
noperspective out vec2 ebPos;
noperspective out vec2 ebCanto;

bool ebCor(vec4 c, vec2 alvo) {
    return c.a > 0.99 && all(lessThan(abs(c.rg - alvo / 255.0), vec2(1.5 / 255.0)));
}

void main() {
    ebBorda = 0;
    ebAlfa = 1.0;
    ebPos = vec2(0.0);
    ebCanto = vec2(0.0);

    // Vermelho #EB0B__ e verde #0BEB__; o azul (203 a 218) é a opacidade em 16 níveis.
    vec4 marca = textureLod(Sampler0, UV0, 0.0);
    float nivel = marca.b * 255.0 - 203.0;
    bool azul = nivel > -0.5 && nivel < 15.5;
    int tipo = !azul ? 0 : ebCor(marca, vec2(235.0, 11.0)) ? 1 : ebCor(marca, vec2(11.0, 235.0)) ? 2 : 0;
    if (tipo != 0) {
        ebAlfa = (floor(nivel + 0.5) + 1.0) / 16.0;
        // Os 4 vértices do quadrado vêm em ordem cíclica; cada um vira um canto da tela. ebPos (canto
        // real, relativo à câmera) e ebCanto (±1) variam juntos de forma afim, e o .fsh tira o centro
        // e o raio dessa relação.
        int i = gl_VertexID & 3;
        vec2 canto = i == 0 ? vec2(-1.0, -1.0) : i == 1 ? vec2(1.0, -1.0) : i == 2 ? vec2(1.0, 1.0) : vec2(-1.0, 1.0);
        ebBorda = tipo;
        ebPos = Position.xz;
        ebCanto = canto;
        gl_Position = vec4(canto, 0.0, 1.0);
        sphericalVertexDistance = 0.0;
        cylindricalVertexDistance = 0.0;
        vertexColor = vec4(1.0);
        texCoord0 = UV0;
        texCoord1 = UV1;
        texCoord2 = UV2;
        return;
    }

    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color) * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;
    texCoord1 = UV1;
    texCoord2 = UV2;
}
