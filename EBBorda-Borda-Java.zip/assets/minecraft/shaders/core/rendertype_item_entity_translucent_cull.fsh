#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl>

// Igual ao vanilla, exceto pelo quadrado marcador do EBBorda: para cada pixel, acha onde o raio da
// câmera bate no cilindro da borda e desenha ali as listras vermelhas do /worldborder.

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;
in vec2 texCoord1;

flat in int ebBorda;
flat in float ebAlfa;
noperspective in vec2 ebPos;
noperspective in vec2 ebCanto;

out vec4 fragColor;

const float TAU = 6.28318530718;
// Listras juntas como as das bordas de battle royale, sobre um fundo rosado translúcido, lentas e,
// onde ficariam mais finas que um pixel (longe, ou olhando para cima), trocadas pela cor média em vez
// de cintilar (pesa menos para quem faz live). A parede sobe até o céu.
const float PERIODO = 0.8;          // blocos entre listras (medido ao longo da parede)
const float LINHA = 0.26;           // espessura da listra, em blocos
const float TOPO = 320.0;           // a parede vai até o limite de altura do mundo
const float VELOCIDADE = 0.08;      // blocos por segundo que as listras sobem
const vec3 COR = vec3(1.0, 0.16, 0.16);
const vec3 FUNDO = vec3(1.0, 0.84, 0.87);
const vec3 COR_ABRINDO = vec3(0.40, 1.0, 0.40);
const vec3 FUNDO_ABRINDO = vec3(0.86, 1.0, 0.86);
const float ALFA = 0.9;
const float ALFA_FUNDO = 0.12;

float listra(float s, float largura) {
    // s em "listras" (linha em cada inteiro). largura = quanto s varia num pixel (antisserrilhado).
    float w = LINHA / PERIODO;
    float d = abs(fract(s + 0.5) - 0.5);
    float aa = max(largura * 0.75, 1.0e-4);
    float linha = 1.0 - smoothstep(w * 0.5 - aa, w * 0.5 + aa, d);
    // Longe ou de raspão várias listras caem no mesmo pixel e piscam: vira a cobertura média.
    return mix(linha, w, smoothstep(0.15, 0.45, largura));
}

void parede(vec3 cor, vec3 fundo) {
    // Centro e raio: ebPos = centro + J * ebCanto, e as derivadas na tela dão J (linha X = raio).
    mat2 dA = mat2(dFdx(ebPos), dFdy(ebPos));
    mat2 dB = mat2(dFdx(ebCanto), dFdy(ebCanto));
    mat2 J = dA * inverse(dB);
    vec2 centro = ebPos - J * ebCanto;
    float raio = abs(J[0][0]) + abs(J[1][0]);

    vec2 ndc = gl_FragCoord.xy / ScreenSize * 2.0 - 1.0;
    mat4 inv = inverse(ProjMat * ModelViewMat);
    vec4 perto = inv * vec4(ndc, -1.0, 1.0);
    vec4 longe = inv * vec4(ndc, 1.0, 1.0);
    vec3 ro = perto.xyz / perto.w;
    vec3 rd = normalize(longe.xyz / longe.w - ro);

    // Sem discard até o fim: as derivadas das listras (fwidth) precisam do bloco 2x2 inteiro.
    float a = max(dot(rd.xz, rd.xz), 1.0e-8);
    vec2 oc = ro.xz - centro;
    float b = dot(oc, rd.xz);
    float c = dot(oc, oc) - raio * raio;
    float disc = b * b - a * c;
    float raiz = sqrt(max(disc, 0.0));
    float t = (-b - raiz) / a;
    if (t <= 0.0) {
        t = (-b + raiz) / a;
    }
    bool acertou = disc >= 0.0 && t > 0.0;
    t = max(t, 0.0);
    vec3 hit = ro + rd * t;

    // Listras de tamanho fixo: posição ao longo da parede = ângulo × raio. Uma volta quase nunca tem um
    // número inteiro de listras, então em algum ponto os dois lados não batem (emenda). Esse ponto fica
    // sempre atrás da câmera: a origem do ângulo vai para a parede à frente (por dentro) ou para o lado
    // virado para a câmera (por fora, a parte de trás nem é desenhada). A origem anda em passos de
    // exatamente uma listra, então mudá-la não muda o desenho, só onde fica a emenda. De quebra, as
    // listras à frente quase não deslizam enquanto a borda fecha/abre.
    vec2 rel = hit.xz - centro;
    vec2 cam = -centro;
    vec3 frente = (inverse(ModelViewMat) * vec4(0.0, 0.0, -1.0, 0.0)).xyz;
    vec2 f2 = dot(frente.xz, frente.xz) > 1.0e-6 ? normalize(frente.xz) : vec2(1.0, 0.0);
    float origem;
    if (dot(cam, cam) > raio * raio) {
        origem = atan(cam.y, cam.x);
    } else {
        float bb = dot(cam, f2);
        float tt = -bb + sqrt(max(bb * bb - (dot(cam, cam) - raio * raio), 0.0));
        vec2 p = cam + tt * f2;
        origem = atan(p.y, p.x);
    }
    float passoAng = PERIODO / max(raio, 1.0e-3);
    origem = floor(origem / passoAng + 0.5) * passoAng;
    float ang = atan(rel.y, rel.x) - origem;
    ang -= TAU * floor((ang + TAU * 0.5) / TAU);
    // Altura no mundo: câmera = CameraBlockPos - CameraOffset (como no terrain.vsh do vanilla).
    float y = hit.y + float(CameraBlockPos.y) - CameraOffset.y;
    float tempo = GameTime * 1200.0 * VELOCIDADE;
    // Variação do ângulo por pixel calculada sem o atan, que pula de +pi para -pi na emenda.
    vec2 drx = dFdx(rel);
    vec2 dry = dFdy(rel);
    float r2 = max(dot(rel, rel), 1.0e-6);
    float dAng = abs(rel.x * drx.y - rel.y * drx.x) / r2 + abs(rel.x * dry.y - rel.y * dry.x) / r2;
    float largura = (dAng * raio + fwidth(y)) / PERIODO;
    float cobertura = listra(ang * raio / PERIODO + (y - tempo) / PERIODO, largura);

    // Some só pela distância na horizontal (o mundo acaba ali); para cima a parede vai até o topo do
    // mundo, e olhando para cima aparece o céu pela abertura.
    float sumir = 1.0 - smoothstep(FogRenderDistanceEnd * 0.75, FogRenderDistanceEnd, length(hit.xz - ro.xz));
    sumir *= 1.0 - smoothstep(TOPO - 8.0, TOPO, y);
    float alfa = mix(ALFA_FUNDO, ALFA, cobertura) * sumir * ebAlfa;
    if (!acertou || alfa < 0.01) {
        discard;
    }

    vec4 clip = ProjMat * ModelViewMat * vec4(hit, 1.0);
    gl_FragDepth = clamp(clip.z / clip.w * 0.5 + 0.5, 0.0, 1.0);
    fragColor = vec4(mix(fundo, cor, cobertura), alfa);
}

void main() {
    if (ebBorda != 0) {
        if (ebBorda == 2) {
            parede(COR_ABRINDO, FUNDO_ABRINDO);
        } else {
            parede(COR, FUNDO);
        }
        return;
    }
    gl_FragDepth = gl_FragCoord.z;
    vec4 color = texture(Sampler0, texCoord0) * vertexColor * ColorModulator;
    if (color.a < 0.1) {
        discard;
    }
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
